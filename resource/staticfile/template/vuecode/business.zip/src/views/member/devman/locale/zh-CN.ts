export default {
  'member.title': '会员管理',
  'member.devman.title': '开发者管理',
};
