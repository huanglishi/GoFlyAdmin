export default {
  path: 'https://goflys.cn',
  name: 'gofly',
  meta: {
    locale: 'GoFly开发社区',
    icon: 'icon-link',
    requiresAuth: true,
    order: 8,
  },
};
