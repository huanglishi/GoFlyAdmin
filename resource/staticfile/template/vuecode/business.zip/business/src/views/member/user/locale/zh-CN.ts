export default {
  'member.user.title': '用户管理',
};
