export default {
  'wxsys.wxsetting.title': 'acount setting',
};
