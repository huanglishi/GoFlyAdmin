export default {
  'wxsys.title': '微信管理',
  'wxsys.wxuser.title': '微信用户',
};
