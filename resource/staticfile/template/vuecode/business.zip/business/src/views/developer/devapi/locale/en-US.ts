export default {
  'developer.title': 'developer',
  'developer.apidoc.title': 'apidoc',
};
