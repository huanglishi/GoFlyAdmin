export default {
  'member.user.title': 'user',
};
