export default {
  'member.title': 'member',
  'member.devman.title': 'Developer',
};
