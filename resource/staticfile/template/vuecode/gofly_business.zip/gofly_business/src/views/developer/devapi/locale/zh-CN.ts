export default {
  'developer.title': '开发者',
  'developer.apidoc.title': '接口文档',
  'developer.apidoc.createapi': '新增api',
  'developer.apidoc.mgroun': '管理分类',
};
