export default {
  'wxsys.title': 'wechat',
  'wxsys.wxuser.title': 'wechat user',
};
