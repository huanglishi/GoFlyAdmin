import Backspace from './backspace';
import Left from './left';
import Right from './right';

export { Backspace, Left, Right };
