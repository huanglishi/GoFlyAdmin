import Default from './default';

class Tab extends Default {
	hotkey = 'tab';
}
export default Tab;
