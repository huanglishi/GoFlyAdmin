import Default from './default';

class Enter extends Default {
	hotkey = 'enter';
}
export default Enter;
