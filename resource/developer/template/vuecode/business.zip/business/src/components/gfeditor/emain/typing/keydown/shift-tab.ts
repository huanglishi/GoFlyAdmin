import Default from './default';

class ShiftTab extends Default {
	hotkey = 'shift+tab';
}
export default ShiftTab;
