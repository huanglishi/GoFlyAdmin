export default {
  'system.dept': '部门管理',
  // columns

};
