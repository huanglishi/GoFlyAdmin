-- ----------------------------
-- MySQL Database Dump
-- Start Time: 2023-12-02 18:28:06
-- ----------------------------


DROP TABLE IF EXISTS `business_auth_dept`;
-- ----------------------------
-- Table structure for business_auth_dept
-- ----------------------------
CREATE TABLE IF NOT EXISTS `business_auth_dept` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `businessID` int(11) NOT NULL DEFAULT '0' COMMENT '业务主账号id',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '添加用户',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '部门名称',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '上级部门',
  `weigh` int(11) NOT NULL COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '备注',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='管理后台部门';



-- ----------------------------
-- Records of business_auth_dept
-- ----------------------------
INSERT INTO `business_auth_dept` VALUES (1,1,1,'市场部门',0,1,0,'营销',1666972562);
INSERT INTO `business_auth_dept` VALUES (2,1,1,'第一组',1,2,0,'',1701187668);
INSERT INTO `business_auth_dept` VALUES (3,1,1,'研发部门',1,3,0,'',1660493302);
INSERT INTO `business_auth_dept` VALUES (4,2,2,'领导部门',0,4,0,'',1660493325);
INSERT INTO `business_auth_dept` VALUES (6,2,2,'人事组',4,6,0,'',1667827895);


DROP TABLE IF EXISTS `business_auth_role`;
-- ----------------------------
-- Table structure for business_auth_role
-- ----------------------------
CREATE TABLE IF NOT EXISTS `business_auth_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `businessID` int(11) NOT NULL DEFAULT '0' COMMENT '业务主账号id',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '添加用户id',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '名称',
  `rules` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '规则ID 所拥有的权限包扣父级',
  `menu` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '选择的id，用于编辑赋值',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态1=禁用',
  `data_access` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据权限0=自己1=自己及子权限，2=全部',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '描述',
  `weigh` int(11) NOT NULL COMMENT '排序',
  `createtime` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='权限分组';



-- ----------------------------
-- Records of business_auth_role
-- ----------------------------
INSERT INTO `business_auth_role` VALUES (1,0,1,0,'超级管理组','*','*',0,0,'账号的总管理员',1,1678549942);
INSERT INTO `business_auth_role` VALUES (5,0,1,1,'销售员2','8,11,13,49,59,6','[8,11,13,49,59]',0,0,'产品销售组',2,1678550158);
INSERT INTO `business_auth_role` VALUES (6,0,1,1,'管理员','7,11,13,32,8,64,61,12,63,6','[7,11,13,32,8,64,61,12,63]',0,0,'',3,1678549964);
INSERT INTO `business_auth_role` VALUES (7,0,1,6,'编辑组','7,34,33,11,12,6','[7,34,33,11,12]',0,0,'',4,1678549960);
INSERT INTO `business_auth_role` VALUES (8,0,1,6,'兼职组','11,12,34,7,33','[11,12,34,7,33]',0,0,'ceshi',5,1667105411);
INSERT INTO `business_auth_role` VALUES (11,0,1,0,'管理组','8,9,10,6','[8,9,10]',0,0,'',11,1678549957);
INSERT INTO `business_auth_role` VALUES (13,0,1,0,'市场部门','8,6','[8]',0,0,'',13,1678549952);
INSERT INTO `business_auth_role` VALUES (16,0,1,0,'财务室','8,48,49,59,69,6','[8,48,49,59,69]',0,0,'修改',16,1678549955);
INSERT INTO `business_auth_role` VALUES (19,1,1,1,'新增权限2','70,68','[70]',0,0,'',19,1701191528);
INSERT INTO `business_auth_role` VALUES (20,1,1,1,'123','97,74,75','[97,74,75]',0,0,'',20,1687527490);


-- ----------------------------
-- Dumped by mysqldump
-- Cost Time: 15.4986ms
-- ----------------------------
