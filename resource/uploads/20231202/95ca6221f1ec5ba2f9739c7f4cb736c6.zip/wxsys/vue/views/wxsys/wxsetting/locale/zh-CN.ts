export default {
  'wxsys.wxsetting.title': '账号配置',
};
