-- ----------------------------
-- MySQL Database Dump
-- Start Time: 2023-11-29 01:32:03
-- ----------------------------


DROP TABLE IF EXISTS `business_wxsys_wxmenu`;
-- ----------------------------
-- Table structure for business_wxsys_wxmenu
-- ----------------------------
CREATE TABLE IF NOT EXISTS `business_wxsys_wxmenu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accountID` int(11) NOT NULL DEFAULT '0' COMMENT '账号id',
  `businessID` int(11) NOT NULL DEFAULT '0' COMMENT '业务主账号id',
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公众号名称',
  `des` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '备注',
  `menu` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '菜单内容',
  `select` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否选择用1=是',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='微站微信菜单';



-- ----------------------------
-- Records of business_wxsys_wxmenu
-- ----------------------------
INSERT INTO `business_wxsys_wxmenu` VALUES (9,1,1,'测试号管理','sssdsss','{"button":[{"name":"菜单名称","type":"view","url":"","sub_button":{"list":[{"name":"子菜单名称","url":"","type":"view"}]}}]}',0);
INSERT INTO `business_wxsys_wxmenu` VALUES (11,1,1,'测试号管理','','{"button":[{"type":"view","url":"","sub_button":{"list":[{"type":"view","name":"子菜单名称","url":""}]},"name":"菜单名称"}]}',0);
INSERT INTO `business_wxsys_wxmenu` VALUES (13,1,1,'公众号菜单1','','{"button":[{"type":"view","url":"","sub_button":{"list":[{"type":"view","name":"子菜单名称","url":""}]},"name":"菜单名称"},{"type":"view","name":"菜单名称","url":""},{"type":"view","name":"菜单名称","url":""}]}',0);


DROP TABLE IF EXISTS `business_wxsys_wxappconfig`;
-- ----------------------------
-- Table structure for business_wxsys_wxappconfig
-- ----------------------------
CREATE TABLE IF NOT EXISTS `business_wxsys_wxappconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accountID` int(11) NOT NULL DEFAULT '0' COMMENT '账号id',
  `businessID` int(11) NOT NULL DEFAULT '0' COMMENT '业务主账号id',
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公众号名称',
  `AppID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '开发者ID(AppID)',
  `AppSecret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '开发者密码(AppSecret)',
  `des` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '备注',
  `expires_access_token` int(11) NOT NULL DEFAULT '0' COMMENT '获取access_token时间',
  `expires_jsapi_ticket` int(11) NOT NULL DEFAULT '0' COMMENT '获取jsapi_ticket时间',
  `qrcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '二维码',
  `Token` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Token 长度为3-32字符',
  `EncodingAESKey` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息加密密钥由43位字符组成',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='微信小程序配置';



-- ----------------------------
-- Records of business_wxsys_wxappconfig
-- ----------------------------
INSERT INTO `business_wxsys_wxappconfig` VALUES (4,19,0,'云律法务咨询','wx73fd73f2ba85dd5d','3bd86536b5dfa0fc2058cce6e9e4b485','云律科技',1680945724,1678878997,'','','',1672367636);
INSERT INTO `business_wxsys_wxappconfig` VALUES (6,1,1,'小程序测试号','wxe91102f7f7dead52','6371e1f0ff2d9ed840ca8ff2809cd838','wxid_jdduiwcre0iv22的接口测试号',0,0,'','','',1681195635);


DROP TABLE IF EXISTS `business_wxsys_user`;
-- ----------------------------
-- Table structure for business_wxsys_user
-- ----------------------------
CREATE TABLE IF NOT EXISTS `business_wxsys_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accountID` int(11) NOT NULL DEFAULT '0' COMMENT '账号id',
  `businessID` int(11) NOT NULL DEFAULT '0' COMMENT '业务主账号id',
  `dept_id` int(11) NOT NULL DEFAULT '0' COMMENT '属于部门',
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户账号',
  `password` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `salt` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码盐',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '姓名',
  `openid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户的标识，对当前公众号唯一',
  `wxapp_openid` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '小程序的openid',
  `unionid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '只有在用户将公众号绑定到微信开放平台帐号后，才会出现该字段。',
  `subscribe` tinyint(1) NOT NULL COMMENT '用户是否订阅该公众号标识，值为0时，代表此用户没有关注该公众号，拉取不到其余信息。',
  `subscribe_time` int(11) NOT NULL DEFAULT '0' COMMENT '用户关注时间，为时间戳。如果用户曾多次关注，则取最后关注时间',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '昵称',
  `avatar` varchar(145) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '头像',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '备注',
  `mobile` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '手机号码',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '邮箱',
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '城市',
  `area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户所在县区',
  `address` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户所在详细地址',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 1=禁用',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='微信关注用户';



-- ----------------------------
-- Records of business_wxsys_user
-- ----------------------------


DROP TABLE IF EXISTS `business_wxsys_officonfig`;
-- ----------------------------
-- Table structure for business_wxsys_officonfig
-- ----------------------------
CREATE TABLE IF NOT EXISTS `business_wxsys_officonfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `accountID` int(11) NOT NULL DEFAULT '0' COMMENT '账号id',
  `businessID` int(11) NOT NULL DEFAULT '0' COMMENT '业务主账号id',
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公众号名称',
  `des` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '备注',
  `AppID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '开发者ID(AppID)',
  `AppSecret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '开发者密码(AppSecret)',
  `expires_access_token` int(11) NOT NULL DEFAULT '0' COMMENT '获取access_token时间',
  `expires_jsapi_ticket` int(11) NOT NULL DEFAULT '0' COMMENT '获取jsapi_ticket时间',
  `access_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'access_token',
  `jsapi_ticket` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'jsapi_ticket',
  `qrcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '二维码',
  `Token` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Token 长度为3-32字符',
  `EncodingAESKey` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息加密密钥由43位字符组成',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='微信公众号配置';



-- ----------------------------
-- Records of business_wxsys_officonfig
-- ----------------------------
INSERT INTO `business_wxsys_officonfig` VALUES (4,19,0,'云律法务咨询','云律科技','wx73fd73f2ba85dd5d','3bd86536b5dfa0fc2058cce6e9e4b485',1680945724,1678878997,'67_D0hSc0ohwRWkRb68_DLRp1zCESdpRG1xAFhTQPVTObZGh16hjwZ7lZwOjPZzd6TsyVEEJoFbhKx6FRvoZDqQN3vHYRXCFsB6tFy_X45sxBqKG0PqC5zkZsnkaqUGNCeAEAQXM','O3SMpm8bG7kJnF36aXbe8-dOkbHtC1tZ-OT1t0-u3u5gk4d9wHinoVzgAtE8ftrBddRNAVPLdfHIV71PemXSZQ','','','',1672367636);
INSERT INTO `business_wxsys_officonfig` VALUES (6,1,1,'测试号管理','微信号： gh_6d5eb37e43d8','wx3c20a30ae0ab44b5','e4ad51399c9e4db1d99aa2a1fe5e2af1',1700909582,0,'74_tsIBWRdgoDZ84FQl6O1rYnVaSHS5uc3TmvMoPMONa_-euA-Gkj-xOyBFWeCV3Ce7ndU-SY5EFcr8Px7U66OpnCAYtkUpTp2tkKIvZk3mFKSNGeYqj2Ha27RNl0MWJDdAIAERL','','https://sg.goflys.cn/common/uploadfile/get_image?url=resource/uploads/20230507/7992812e7e9f2b140968ba3874de1d1a.jpg','19ibcTXUf','WPhI4Izo8aLtcvO9EjYSfA7LolcEyqPCKiqWGM44xrS',1688536087);


-- ----------------------------
-- Dumped by mysqldump
-- Cost Time: 3.5297ms
-- ----------------------------
